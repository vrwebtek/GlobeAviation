<?php 
$fname=$_POST["fname"];
$lname=$_POST["lname"];
$email=$_POST["email"];
$phone=$_POST["phone"];
$part1=$_POST["part1"];
$q1=$_POST["q1"];
$desc1=$_POST["desc1"];
$part2=$_POST["part2"];
$q2=$_POST["q2"];
$desc2=$_POST["desc2"];

$EmailSubject = 'Need Quote'; 

$mailheader = "From: ".$email."\r\n"; 
$mailheader .= "Reply-To: ".$email."\r\n"; 

$mailheader .= "Content-type: text/html; charset=iso-8859-1\r\n"; 
$bodys .= "Name: ".$fname." ".$lname." <br><br>";
$bodys .= "Email Id: ".$email." <br><br>";
$bodys .= "Part 1: ".$part1." <br><br>";
$bodys .= "Part 1 Description: ".$desc1." <br><br>";
$bodys .= "Part 1 Quantity: ".$q1." <br><br>";
if($part2!="" || $desc2!="")
{
	$bodys .= "Part 2: ".$part2." <br><br>";
$bodys .= "Part 2 Description: ".$desc2." <br><br>";
$bodys .= "Part 2 Quantity: ".$q2." <br><br>";
}
$bodys .= "Phone Number: ".$phone." <br><br>";

$emailname = "info@globeaviation.in";

mail("$emailname",$EmailSubject, $bodys, $mailheader) or die ("Failure");
?>

<script language="javascript">
	alert("Email Send Sucessfully");
	window.location = "get a quote.html";
</script>