var mystic;

/*
|--------------------------------------------------------------------------
| GOOGLE MAPS
|--------------------------------------------------------------------------
*/

function init_google_map() {
	var point = new google.maps.LatLng(53.337574, -6.259713);
	var mapOptions = {
		zoom: 15,
		center: point,
		mapTypeId: google.maps.MapTypeId.ROADMAP
	}
	var map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
	var marker = new google.maps.Marker({
		position: point,
		map: map
	});
	$(window).unload(function() { 
		GUnload(); 
	});
}


/*
|--------------------------------------------------------------------------
| MENU
|--------------------------------------------------------------------------
*/

jQuery(document).ready(function() {

	jQuery(".dropmenu a,img.wp-post-image, a.thumbLink").removeAttr("title");
	
	jQuery(".dropmenu > li > ul").parent().children("a").append("<span class='menuPlus'>+</span>");
	jQuery(".dropmenu > li > ul > li > ul").parent().children("a").prepend("<span class='menuArrow'>+</span>");
	jQuery(".dropmenu ul").css("display", "none"); // Opera Fix
	jQuery(".dropmenu li").hover(function(){
		jQuery(this).find('ul:first').slideDown(100);
		},function(){
		jQuery(this).find('ul:first').slideUp(100);
	});

}
)(jQuery);

/*
|--------------------------------------------------------------------------
| UItoTop jQuery Plugin 1.1
| http://www.mattvarone.com/web-design/uitotop-jquery-plugin/
|--------------------------------------------------------------------------
*/

(function($){
	$.fn.UItoTop = function(options) {

 		var defaults = {
			text: 'To Top',
			min: 200,
			inDelay:600,
			outDelay:400,
  			containerID: 'toTop',
			containerHoverID: 'toTopHover',
			scrollSpeed: 1200,
			easingType: 'linear'
 		};

 		var settings = $.extend(defaults, options);
		var containerIDhash = '#' + settings.containerID;
		var containerHoverIDHash = '#'+settings.containerHoverID;
		
		$('body').append('<a href="#" id="'+settings.containerID+'">'+settings.text+'</a>');
		$(containerIDhash).hide().click(function(){
			$('html, body').animate({scrollTop:0}, settings.scrollSpeed, settings.easingType);
			$('#'+settings.containerHoverID, this).stop().animate({'opacity': 0 }, settings.inDelay, settings.easingType);
			return false;
		})
		.prepend('<span id="'+settings.containerHoverID+'"></span>')
		.hover(function() {
				$(containerHoverIDHash, this).stop().animate({
					'opacity': 1
				}, 600, 'linear');
			}, function() { 
				$(containerHoverIDHash, this).stop().animate({
					'opacity': 0
				}, 700, 'linear');
			});
					
		$(window).scroll(function() {
			var sd = $(window).scrollTop();
			if(typeof document.body.style.maxHeight === "undefined") {
				$(containerIDhash).css({
					'position': 'absolute',
					'top': $(window).scrollTop() + $(window).height() - 50
				});
			}
			if ( sd > settings.min ) 
				$(containerIDhash).fadeIn(settings.inDelay);
			else 
				$(containerIDhash).fadeOut(settings.Outdelay);
		});

};
})(jQuery);